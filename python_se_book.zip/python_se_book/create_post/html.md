# 自学内容: html基础知识

### 目标

* 知道什么是html标签，什么是dom元素，什么是dom元素的属性
* 看到页面上的某个元素，能大概知道这个元素对应的html是什么
* 能看懂复杂的html元素的层次关系，知道某个元素的父元素是什么，子元素又是什么
* 能看懂表单的html代码，知道每个元素长什么样，有什么作用

### 自学内容

建议花费时间: **12小时**

[HTML教程](http://www.w3school.com.cn/html/index.asp)

如果你时间有限，可以重点关注以下章节

* [简介](http://www.w3school.com.cn/html/html_intro.asp)
* [基础](http://www.w3school.com.cn/html/html_basic.asp)
* [元素](http://www.w3school.com.cn/html/html_elements.asp)
* [属性](http://www.w3school.com.cn/html/html_attributes.asp)
* [标题](http://www.w3school.com.cn/html/html_headings.asp)
* [段落](http://www.w3school.com.cn/html/html_paragraphs.asp)
* [css](http://www.w3school.com.cn/html/html_css.asp)
* [链接](http://www.w3school.com.cn/html/html_links.asp)
* [图像](http://www.w3school.com.cn/html/html_images.asp)
* [表格](http://www.w3school.com.cn/html/html_tables.asp)
* [class](http://www.w3school.com.cn/html/html_classes.asp)
* [iframe](http://www.w3school.com.cn/html/html_iframe.asp)
* [form表单](http://www.w3school.com.cn/html/html_forms.asp)
* [表单元素](http://www.w3school.com.cn/html/html_form_elements.asp)
* [输入类型](http://www.w3school.com.cn/html/html_form_input_types.asp)
* [输入属性](http://www.w3school.com.cn/html/html_form_attributes.asp)


### 练习

[在线练习](http://www.w3school.com.cn/example/html_examples.asp)

### 测验

[在线测验](http://www.w3school.com.cn/html/html_quiz.asp)
