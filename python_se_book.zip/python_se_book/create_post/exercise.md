# 练习

### 将qq.com首页上的今日话题的内容自动发表到自己的blog

![](./imgs/qq_daily.png)

步骤：

* 打开qq首页
* 获取今日话题的url和标题
* get到这个url，拿到这篇文章正文的html
* 登录wordpress
* 到创建文章页面
* 用```set_content()```方法，把html传进去
* 点击创建


### 实现创建post的数据驱动

给你1个json文件:data.json，内容如下

```javascript
[{"title": "Don't cry because it's over, smile because it happened", "content": "Don't cry because it's over, smile because it happened. By Dr. Seuss"}, {"title": "Be yourself; everyone else is already taken", "content": "Be yourself; everyone else is already taken. By Oscar Wilde"}, {"title": "So many books, so little time", "content": "So many books, so little time. By  Frank Zappa"}]
```

读取这个文件，创建3篇文章，一定要用到for循环。


### 粉丝反馈表单的自动化脚本

链接

[粉丝反馈表](https://jinshuju.net/f/kRXoEv)

要求

* 服务质量5颗星
* 喜欢的内容选择**各种公开课**
* 对交流群的意见需要填写
* 留下自己正确的联系方式
* 点击提交

断言

不需要断言，能符合上面的要求成功提交就可以

### 天气提醒

假如你是某公司的hr，请从[中国天气网](http://www.weather.com.cn)或者[百度天气]()获取当地明天的天气情况，如果明天下雨，请发送邮件通知全体同事带伞，如果明天气温低于10度，请邮件提醒同事注意保暖，如果气温高于30度则提醒同事注意高温。假设存在发送邮件的方法self.send_email(email_content)

参考实现：

```python
class WeatherNotification:
  def send_email(self, email, content):
    # 假设这个方法已经实现了

  def get_temperature(self):
    pass

  def get_weather(self):
    pass

  def send_notification(self, email):
    weather = self.get_weather()
    temmperature = self.get_temperature()

    content = ''

    if weather == 'raining':
      content += '明天下雨，'
    else:
      content += '明天晴天，'

    if temmperature < 10:
      content += '温度低于10度，请注意保暖'

    if temmperature > 30:
      content += '温度高于30度，请注意高温'

    self.send_email(email, content)
```
