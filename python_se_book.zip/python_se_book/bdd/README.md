本章主要内容

* bdd介绍
* behave框架介绍
* 使用behave框架实现wordpress测试用例
