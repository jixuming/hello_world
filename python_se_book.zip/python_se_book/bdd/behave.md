# behave测试框架

[behave](https://pythonhosted.org/behave/)是python的1个bdd测试框架实现。

### 安装

```
pip install behave
```

### 教程

[英文教程](https://pythonhosted.org/behave/tutorial.html)

### 使用behave重构wordpress测试用例

框架目录

wordpress_bdd
  -features # feature和step的存放路径
    - steps # steps存放路径
      - lib # 公共库路径
      - pages # po 路径
      - create_post_step.py # 具体的step文件
      - login-step.py
    - environment.py # 配置文件
    - login.feature # 具体的feature文件
    - create_post.feature
  -report # 测试报告目录

定义login.feature

```
Feature: Login

  @login # 定义tag是login
  Scenario: Success
    Given go to login page
    When login with admin admin
    Then redirect to dashboard page
    And display hello admin
```

定义测试步骤login_step.py

```python

from behave import *
from pages import login_page

@given(u'go to login page')
def step_impl(context):
	context.login_page = login_page.LoginPage(context.dr)
	context.login_page.url = context.login_page.domain + 'wp-login.php'
	context.login_page.navigate()

@when(u'login with {user_name} {password}')
def step_impl(context, user_name, password):
	context.dashboard_page = context.login_page.login(user_name, password)

@then(u'redirect to dashboard page')
def step_impl(context):
	assert 'wp-admin' in context.dr.current_url

@then(u'display hello {user_name}')
def step_impl(context, user_name):
	greeking_link = context.dashboard_page.greeking_link
	assert user_name in greeking_link.text
```

运行，注意一定要在wordpress_bdd路径下

```
behave -t login --junit
```

上面的命令表示运行tag是login的用例并输出junit格式测试报告


### 总结

behave的功能相当丰富健全，希望大家可以深入研究并集成到自己的测试框架中去。

更多wordpress bdd实例代码请查看src/wordpress_bdd路径。
