# BDD介绍

### 什么是BDD

Behavior-driven development

In software engineering, behavior-driven development (BDD) is a software development process that emerged from test-driven development (TDD).Behavior-driven development combines the general techniques and principles of TDD with ideas from domain-driven design and object-oriented analysis and design to provide software development and management teams with shared tools and a shared process to collaborate on software development

[详情](https://en.wikipedia.org/wiki/Behavior-driven_development)

### BDD产生的背景

* 软件与客户需求之间出现偏差
* 开发与需求之间产生理解误差
* 开发与测试对需求产生偏差
* 测试与产品经理对需求的理解不一致

为什么软件开发过程中会出现这么多问题呢？

* 站在不同的角度看问题
* 客户的需求未真正理解并传达
* 客户不知道如何去表述需求
* 客户与软件开发者所处行业不同

### 如何解决这些问题

采用BDD工作流

首先我们需要跟客户说同一种语言(DSL)，也就是站在同一个维度讨论问题。比如我们规定一些专有名词，B端表示卖家，C端表示买家之类的。

1. 客户先描述需求
2. 根据需求先写出自然语言的用例(用例即文档)
3. 实现用例
4. 运行用例
5. 用例运行失败
6. fix失败用例
7. 添加用例
8. 运行用例
9. ...
10. ...
11. ...

### BDD术语

* Feature: 用例名
* Scenaro: 测试场景
* Given: 前置条件，对应3A里的arrange
* When: 测试步骤，对应3A里的act
* Then: 断言，对应3A里的assert
