# 最简单的测试job

### 需求

现在有一个单元测试任务，要求每隔15分钟运行一次，并且要求整个团队都可以实时看到测试结果。

```python
import unittest

class StringTestCase(unittest.TestCase):

    def setUp(self):
        self.test_string = "This is a string"

    def testReverse(self):
        self.assertEqual("gnirts a si sihT", self.test_string[::-1])

    def testSplit(self):
        expected = ["This", "is", "a", "string"]
        self.assertEqual(expected, self.test_string.split(" "))
        self.assertEqual(expected, self.test_string.split())

    def testLower(self):
        self.assertEqual("this is a string", self.test_string.lower())

    def testUpper(self):
        self.assertEqual("THIS IS A STRING", self.test_string.upper())

    def testRstrip(self):
        string = "This is a string               "
        self.assertEqual(self.test_string, string.rstrip())

    def testLstrip(self):
        string = "            This is a string"
        self.assertEqual(self.test_string, string.lstrip())

    def testStrip(self):
        string = "            This is a string             "
        self.assertEqual(self.test_string, string.strip())


if __name__ == '__main__':
    unittest.main()

```

### 配置jenkins job

看图说话

![](imgs/new_item.png)

新建job

---------------

![](imgs/freestyle.png)

选择free style job

---------------

![](imgs/config_1.gif)

* 配置jenkins只保留最新的5次构建的结果，这样做可以节省硬盘空间
* 设置构建任务的workspace，也就是说构建任务默认会在这个目录下进行

---------------

![](imgs/config_2.gif)

* 配置每隔15分钟执行一次测试
* 配置测试执行脚本，也就是直接运行python unittest代码 ```python string_test_case.py```

---------------

### 手动执行job

看图说话

![](imgs/run.gif)

* 在项目主页，一般是[http://localhost:8080/jenkins/job/python_string_test/]选择**Build Now**
* 点击进入最新的build结果
* 选择**Console Output**查看命令行执行结果


### 总结

* jenkins的job实际上就是各种策略触发的一些任务，常见策略有定制任务，代码提交自动触发任务等
* jenkins的job核心就是在命令行中执行各种命令，这也是为什么我们以前的课程代码全部都在命令行里跑的原因，因为只要能在命令行跑通就可以顺利的集成到jenkins job里
