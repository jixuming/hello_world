# Summary

* [简介](README.md)

* [第1章](init_env/README.md)
  * [安装wamp及wordpress](init_env/init.md)
  * [wordpress登录的测试用例](init_env/login_case.md)
  * [练习](init_env/exercise.md)

* [第2章](create_post/README.md)
  * [html基础知识](create_post/html.md)
  * [创建文章](create_post/create_post.md)
  * [练习](create_post/exercise.md)

* [第3章](delete_post/README.md)
  * [css选择器](delete_post/css.md)
  * [删除文章](delete_post/delete_post.md)
  * [练习](delete_post/exercise.md)

* [第4章](create_tag/README.md)
  * [创建和删除标签](create_tag/create_tag.md)
  * [练习](create_tag/exercise.md)

* [第5章](po/README.md)
  * [关于Page Object设计模式](po/about.md)
  * [使用po重构wordpress测试用例](po/refactor.md)
  * [练习](po/exercise.md)

* [第6章](nose2_framework/README.md)
  * [基于nose2的简单测试框架](nose2_framework/introduce.md)

* [第7章](ci/README.md)
  * [持续集成简介](ci/ci.md)
  * [安装](ci/install.md)
  * [最简单的测试job](ci/dead_simple_test_job.md)
  * [git支持及代码库监控](ci/git.md)
  * [实战：使用jenkins运行wordpress测试用例](ci/exercise.md)

* [第8章](bdd/README.md)
  * [bdd介绍](bdd/introduce.md)
  * [behave及wordpress重构](bdd/behave.md)
