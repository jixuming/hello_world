#!/usr/bin/env python
# -*- coding:utf-8 -*-
# created by dwm on 2018/11/18

from .base_page import BasePage
from .dashboard_page import DashboardPage
from selenium import webdriver

class LoginPage(BasePage):
    @property
    def usename_text(self):
        return self.by_id('user_login')

    @property
    def passwd_text(self):
        return self.by_id('user_pass')

    @property
    def submit_button(self):
        return self.by_id('wp-submit')

    def login(self, username, passwd):
        self.usename_text.send_keys(username)
        self.passwd_text.send_keys(passwd)
        self.submit_button.click()

        return DashboardPage(self.dr)
        # return self.by_css('#wp-admin-bar-my-account .ab-item').text


if __name__ == '__main__':
    dr = webdriver.Chrome()
    domain = "http://139.199.192.100:8000/"
    username = "admin"
    passwd = "2JpZtOpDlPnCmXVE@P"
    login_page = LoginPage(dr, domain + "wp-login.php")
    dashboard_page = login_page.login(username, passwd)