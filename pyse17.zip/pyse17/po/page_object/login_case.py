#!/usr/bin/env python
# -*- coding:utf-8 -*-
# created by dwm on 2018/11/18

import unittest
from selenium import webdriver
from .login_page import LoginPage
# from .dashboard_page import DashboardPage

class LoginCase(unittest.TestCase):
    def setUp(self):
        self.dr = webdriver.Chrome()
        self.domain = "http://139.199.192.100:8000/"

    def test_login(self):
        username = "admin"
        passwd = "2JpZtOpDlPnCmXVE@P"
        login_page = LoginPage(self.dr, self.domain + "wp-login.php")
        dashboard_page = login_page.login(username, passwd)

        self.assertTrue("wp-admin" in self.dr.current_url)
        # self.assertTrue(username in dashboard_page)
        self.assertTrue(username in dashboard_page.greeting_link.text)

    def tearDown(self):
        self.dr.quit()


if __name__ == '__main__':
    unittest.main()