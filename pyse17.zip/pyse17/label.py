#!/usr/bin/env python
# -*- coding:utf-8 -*-
# created by dwm on 2018/11/10

from urllib import parse
import unittest
from selenium import webdriver
import time
from selenium.webdriver.common.action_chains import ActionChains


class Label(unittest.TestCase):

    def setUp(self):
        self.dr = webdriver.Chrome()
        self.dr.maximize_window()
        self.dr.implicitly_wait(10)
        self.dr.get("http://139.199.192.100:8000/wp-login.php")

    def test_create_label(self):
        self.login_admin()
        tag_name = "星期天%s" %(round(time.time()))
        self.create_label(tag_name)
        # assert
        table = self.by_id("the-list")
        create_success = True
        try:
            table.find_element_by_link_text(tag_name)
        except:
            create_success = False
        self.assertTrue(create_success)

    def test_delete_label(self):
        self.login_admin()
        tag_name = "星期天%s" %(round(time.time()))
        label_id = self.return_label_id(tag_name)
        tag_id = "tag-" + label_id
        self.delete_label(tag_id)
        #assert
        delete_success = True
        try:
            self.by_id(tag_id).find_element_by_link_text(tag_name)
        except:
            delete_success = False
        self.assertFalse(delete_success)

    def create_label(self, tag_name):
        self.dr.get("http://139.199.192.100:8000/wp-admin/edit-tags.php?taxonomy=post_tag")
        self.by_id("tag-name").send_keys(tag_name)
        time.sleep(2)
        self.by_id("submit").click()
        # js = "document.querySelectorAll('#submit')[0].click()"
        # self.dr.execute_script(js)
        time.sleep(1)

    def return_label_id(self, tag_name):
        self.create_label(tag_name)
        # href_link = self.by_id("the-list").find_element_by_link_text(tag_name)
        href_link = self.by_css('#the-list .row-title')
        href = href_link.get_attribute("href")
        return self.url_split(href)

    def url_split(self, url):
        out = parse.urlparse(url)
        res = parse.parse_qs(out.query)
        print (res['tag_ID'])
        return res['tag_ID'][0]

    def delete_label(self, tag_id):
        self.dr.get("http://139.199.192.100:8000/wp-admin/edit-tags.php")
        self.disable_confirm()
        local = self.by_id(tag_id)
        ActionChains(self.dr).move_to_element(local).perform()
        local.find_element_by_css_selector(".delete").click()
        time.sleep(2)

    def disable_confirm(self):
        js = 'window.confirm=function(msg){console.log(msg);return true;};'
        # js = 'window.alert=function(msg){console.log(msg);return true;};'
        self.dr.execute_script(js)

    def login(self, username, passwd):
        self.by_id("user_login").send_keys(username)
        self.by_id("user_pass").send_keys(passwd)
        self.by_id("wp-submit").click()

    def login_admin(self):
        username = "admin"
        passwd = "2JpZtOpDlPnCmXVE@P"
        self.login(username, passwd)

    def by_id(self, the_id):
        return self.dr.find_element_by_id(the_id)

    def by_css(self, css):
        return self.dr.find_element_by_css_selector(css)

    def tearDown(self):
        self.dr.quit()

if __name__ == '__main__':
    unittest.main()