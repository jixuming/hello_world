#!/usr/bin/env python
# -*- coding:utf-8 -*-
# created by dwm on 2018/11/4


import unittest
from selenium import webdriver
from time import sleep


class Login(unittest.TestCase):

    def setUp(self):
        self.username = self.password = "pyse17"
        self.dr = webdriver.Chrome()
        self.dr.implicitly_wait(10)
        self.dr.maximize_window()
        self.dr.get("http://139.199.192.100:8000/")

    def test_login(self):
        self.by_text("登录").click()
        self.by_id("user_login").send_keys(self.username)
        self.by_id("user_pass").send_keys(self.password)
        self.by_id("wp-submit").click()

        #断言
        self.assertIn("wp-admin", self.dr.current_url)

        link = self.by_css('#wp-admin-bar-my-account>.ab-item')
        print(link.text)
        self.assertTrue(self.username in link.text)


        sleep(3)

    def by_text(self, text):
        return self.dr.find_element_by_link_text(text)

    def by_id(self, id):
        return self.dr.find_element_by_id(id)

    def by_css(self, css):
        return self.dr.find_element_by_css_selector(css)

    def tearDown(self):
        self.dr.quit()


if __name__ == '__main__':
    unittest.main()