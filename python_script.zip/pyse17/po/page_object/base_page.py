#!/usr/bin/env python
# -*- coding:utf-8 -*-
# created by dwm on 2018/11/14

from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.wait import WebDriverWait

TIME_OUT = 10
class BasePage(object):
    url = None
    dr = None
    domain = None

    def __init__(self, dr, page_url=None):
        self.dr = dr
        self.url = page_url
        self.domain = "http://139.199.192.100:8000/"
        if self.url is None:
            self.dr.get(self.url)

    def element_by_css(self, elemnt, text):
        self.dr.find_element_by_css_selector(elemnt).send_keys(text)

    def by_id(self, the_id):
        locate = (By.ID, the_id)
        WebDriverWait(self.dr, TIME_OUT).until(EC.presence_of_element_located(locate))
        return self.dr.find_element_by_id(the_id)

    def by_name(self, the_name):
        locate = (By.NAME, the_name)
        WebDriverWait(self.dr, TIME_OUT).until(EC.presence_of_element_located(locate))
        return self.dr.find_element_by_name(the_name)

    def by_css(self, the_css):
        locate = (By.CSS_SELECTOR, the_css)
        WebDriverWait(self.dr, TIME_OUT).until(EC.presence_of_element_located(locate))
        return self.dr.find_element_by_css_selector(the_css)

    def js(self, js_text):
        return self.driver.execute_script(js_text)









if __name__ == '__main__':
    pass