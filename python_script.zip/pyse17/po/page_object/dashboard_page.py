#!/usr/bin/env python
# -*- coding:utf-8 -*-
# created by dwm on 2018/11/18

from base_page import BasePage

class DashboardPage(BasePage):
    @property
    def greeting_link(self):
        return self.by_css('#wp-admin-bar-my-account .ab-item')


if __name__ == '__main__':
    pass