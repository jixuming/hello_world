#!/usr/bin/env python
# -*- coding:utf-8 -*-
# created by dwm on 2018/11/10

import unittest
from selenium import webdriver
import time
from selenium.webdriver.common.action_chains import ActionChains
from selenium.common.exceptions import NoSuchElementException


class DeleteArticle(unittest.TestCase):

    def setUp(self):
        self.dr = webdriver.Chrome()
        self.dr.maximize_window()
        self.dr.implicitly_wait(10)
        self.dr.get("http://139.199.192.100:8000/wp-login.php")

    def tearDown(self):
        self.dr.quit()

    def test_delete_article(self):
        self.login_pyse17()
        title = "this is my article title %s" % (round(time.time()))
        text = "ceshi"
        article_id = self.get_id(title, text)
        post_id = "post-" + article_id
        self.dr.get("http://139.199.192.100:8000/wp-admin/edit.php")
        article_local = self.by_id(post_id)
        ActionChains(self.dr).move_to_element(article_local).perform()
        self.dr.find_element_by_css_selector('a.submitdelete').click()
        # self.by_css('a.submitdelete').click()
        # article_local.self.by_css("a.submitdelete").click()
        # article_local.find_element_by_css_selector('a.submitdelete').click()
        with self.assertRaises(NoSuchElementException):
            self.by_id(post_id)

    def create_article(self, title, content):
        self.dr.get("http://139.199.192.100:8000/wp-admin/post-new.php")
        self.by_id("title").clear()
        self.by_id("title").send_keys(title)
        self.set_content(content)
        self.by_id("publish").click()

    def set_content(self, text):
        # js = 'document.getElementById("content_ifr").contentWindow.document.body.innerHTML="%s"' %(text)
        # print(js)
        # self.dr.execute_script(js)
        self.dr.switch_to.frame("content_ifr")
        # self.by_css("#tinymce > p").clear()
        self.dr.find_element_by_css_selector("#tinymce > p").send_keys(text)

    def get_id(self, title, content):
        self.create_article(title, content)
        return self.by_id("sample-permalink").text.split("=")[-1]

    def login(self, username, passwd):
        self.by_id("user_login").send_keys(username)
        self.by_id("user_pass").send_keys(passwd)
        self.by_id("wp-submit").click()

    def login_pyse17(self):
        username = passwd ="pyse17"
        self.login(username, passwd)

    def by_id(self, the_id):
        return self.dr.find_element_by_id(the_id)

    def by_css(self, css):
        return self.dr.find_element_by_css_selector(css)


if __name__ == '__main__':
    unittest.main()
