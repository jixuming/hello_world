#!/usr/bin/env python
# -*- coding:utf-8 -*-
# created by dwm on 2018/11/10

#coding: utf-8
import unittest
from selenium import webdriver
from selenium.webdriver.common.action_chains import ActionChains
from urlparse import urlparse, parse_qs
import time
from page.login_page import LoginPage
from page.dashboard_page import DashboardPage

class LoginCase(unittest.TestCase):

    def setUp(self): #每个用例执行之前执行
        print 'before test'
        self.domain = 'http://localhost/wordpress/'
        self.dr = webdriver.Firefox()

    def test_login_success(self):
        username = password = 'admin'
        login_page = LoginPage(self.dr, self.domain + 'wp-login.php')
        dashboard_page = login_page.login(username, password)

        self.assertTrue('wp-admin' in self.dr.current_url)
        self.assertTrue(username in dashboard_page.greeting_link.text)

    def tearDown(self): #每个用例执行之后
        print 'after every test'
        self.dr.quit()



if __name__ == '__main__':
    pass