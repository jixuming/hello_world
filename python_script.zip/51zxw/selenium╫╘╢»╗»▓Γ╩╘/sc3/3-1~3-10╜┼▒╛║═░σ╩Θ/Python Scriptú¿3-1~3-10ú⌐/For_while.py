student=['Jack','Bob','Marry','Micle']
for stu in student:
    print(stu)

sum=0
for i in range(11):
    sum=sum+i
print(sum)

n=10
while n>0:
    n=n-1
    print(n)
print("over!")