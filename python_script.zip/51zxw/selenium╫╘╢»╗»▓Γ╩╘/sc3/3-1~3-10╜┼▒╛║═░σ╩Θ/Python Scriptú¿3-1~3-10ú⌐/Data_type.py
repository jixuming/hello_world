x=5
y=5
#z=x+y
print(x+y)

f=5.30
l=5.20
a=f+l
print()

str="hello \n 51zxw"
print(str)

print("c:\\python35")

print('My name is \'Jack\' and \"you\"')

t=True
f=False
print(t and f)