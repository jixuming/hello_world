student={1:'jack',2:'Bob',3:'Marry',4:'Micle'}
print(student[3])

student[5]='51zxw'
print(student)

student[2]='Harry'
print(student)

del student[2]
print(student)

student.clear()
print(student)

del student
print(student)
