student=['jack','Bob','Harry','Micle']
print(student)

print(student[3])
print(student[-1])
#print(student[4])

student.append('51zxw')
print(student)

student.insert(0,'hello')
print(student)

student[0]='No.1'
print(student)

student.pop()
print(student)

student.pop(1)
print(student)
