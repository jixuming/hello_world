course=('Chinese','English','Math','computer')
print(course)
print(course[-1])
print(course[1:])
print(course[:2])

print(len(course))

score=(78,88,90,65,79)
maxScore=max(score)
print(maxScore)
