score=100
if score>=80:
    print("Score is A")
elif score>=60:
    print("Score is B")
else:
    print("Score is C")