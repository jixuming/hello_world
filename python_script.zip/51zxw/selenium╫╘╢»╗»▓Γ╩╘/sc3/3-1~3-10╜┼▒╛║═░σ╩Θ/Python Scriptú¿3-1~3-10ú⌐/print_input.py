'''
print('hello,51zxw')
print("are","you","OK?")

#打印整数
print(300)
print(300+200)

name="51zxw"
print("hello,%s" %name)

width=30
print("width is %d" %width)
'''
con=input("Please input Content ")
print(" Content is %r" %con)