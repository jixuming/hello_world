def Max_num(a,b):
    if a>b:
        return a
    elif a<b:
        return b
    else:
        return a

result=Max_num(50,10)
print(result)