name='Jack'
city='Beijing'
print("My name is %s and come from %s" %(name,city))
print("hello,51zxw")

name='Harry'
city='Shanghai'
print("My name is %s and come from %s" %(name,city))
print("hello,51zxw!")