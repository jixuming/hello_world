#coding:utf8
from selenium import webdriver
import unittest
from time import sleep

class loginTest(unittest.TestCase):
    def setUp(self):
        self.driver = webdriver.Chrome()
        self.driver.implicitly_wait(10)
        self.url='https://www.tapd.cn/cloud_logins/login'
    def tearDown(self):
        self.driver.quit()
    def test1(self):
        driver = self.driver
        driver.get(self.url)
        driver.find_element_by_id('username').send_keys('13265862660')
        driver.find_element_by_id('password_input').send_keys('680795242779dwm*')
        #sleep(3)
        driver.find_element_by_id('tcloud_login_button').click()

if __name__ == "__main__":
    unittest.main()



#driver.get('https://www.tapd.cn/cloud_logins/login')
#driver.find_element_by_id('username').send_keys('13265862660')
#driver.find_element_by_id('password_input').send_keys('680795242779dwm*')
#driver.find_element_by_id('tcloud_login_button').click()

#driver.quit()

