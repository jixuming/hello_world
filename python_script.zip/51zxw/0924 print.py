"""
width=30
print ("the width is %d" %width)

con = input("please input context")
print("content is %s" %con)

"""
print("hello \n world")

print('my name is \'jack\' and \"you \"')

student = ['jack', 'tom', 'bob']
print(student)
print(student[0])
print(student[-1])
student.append('51zxw')
print(student)
student.insert(1, 'hello')
print(student)
student[0] = 'no1'
print(student)
student.pop()
print(student)
student.pop(1)
print(student)
print(len(student))
