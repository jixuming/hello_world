#coding:utf8

from selenium import webdriver
from time import sleep
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By

class BasePage(object):
    def __init__(self):
        self.driver = webdriver.Chrome()
        url='https://www.baidu.com'
        self.open_url(url)

    def by_clss(self,css):
        locator = (By.CSS_SELECTOR,css)
        WebDriverWait(self.driver,10,0.1).until(EC.visibility_of_all_elements_located(locator))
        return self.driver.find_element_by_css_selector(css)

    def __css__(self,css):
        return self.driver.find_element_by_css_selector(css)
    def __xpath__(self,xpath):
        return self.driver.find_element_by_xpath(xpath)
    def __text__(self,text):
        return self.driver.find_element_by_link_text(text)
    def open_url(self,url):
        self.driver.get(url)
    def quit(self):
        self.driver.quit()

if __name__ == '__main__':
    b = BasePage()
    b.by_clss('#u1 > a:nth-child(1)').click()
  #  b.by_clss("#u1 a.mnav[name='tj_trnews']").click()
    b.quit()


