#!/usr/bin/env python
# -*- coding:utf-8 -*-
# created by dwm on 2018/10/4

from selenium import webdriver
from time import sleep

driver = webdriver.Chrome()
driver.maximize_window()
sleep(3)
"""
driver.get('http://www.51zxw.net/')
driver.maximize_window()
print(driver.title)
sleep(2)

driver.get('http://www.51zxw.net/list.aspx?cid=615')
driver.set_window_size(400, 880)
driver.refresh()
sleep(2)

driver.back()
sleep(2)
driver.forward()
sleep(2)

driver.get('http://www.baidu.com')
driver.find_element_by_name('wd').send_keys('51zxw')
driver.find_element_by_id("su").click()
sleep(4)
"""

driver.get('http://www.51zxw.com/')
driver.find_elements_by_tag_name("input")[0].send_keys("selenium")
sleep(2)
driver.find_element_by_link_text("程序开发").click()
driver.find_element_by_partial_link_text("C语言").click()



driver.quit()

