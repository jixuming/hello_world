#!/usr/bin/env python
# -*- coding:utf-8 -*-
# created by dwm on 2018/10/7


from selenium import webdriver
from time import sleep

driver = webdriver.Chrome()
driver.maximize_window()
driver.get('http://www.51zxw.net')
cookies = driver.get_cookies()
print(cookies)
print(cookies[0])

driver.quit()



if __name__ == '__main__':
    pass