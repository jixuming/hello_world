#!/usr/bin/env python
# -*- coding:utf-8 -*-
# created by dwm on 2018/10/7

from selenium import webdriver
from time import sleep
import os
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By

# file_path = os.path.abspath('change.log')
# print(file_path)
drive = webdriver.Chrome()
drive.maximize_window()
drive.get('http://www.baidu.com')
drive.find_element_by_css_selector('.soutu-btn').click()
sleep(2)
drive.find_element_by_css_selector('input[value="上传图片"]').send_keys(r"F:\自动化学习\51自学网\selenium自动化测试\sc4\脚本与课件\4-22~4-32 Script\shuiyin.png")
# sleep(5)
element = WebDriverWait(drive, 10, 1).until(EC.presence_of_element_located((By.ID, 'imgfile')))



drive.quit()


if __name__ == '__main__':
    pass