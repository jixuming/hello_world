#!/usr/bin/env python
# -*- coding:utf-8 -*-
# created by dwm on 2018/10/6


from selenium import webdriver
from time import sleep

driver = webdriver.Chrome()
driver.maximize_window()
driver.get('http://www.51zxw.net/list.aspx?cid=615')
home_handle = driver.current_window_handle

# driver.find_element_by_css_selector('a:contains("2-1 走进Selenium新世界")').click()

#j_th > table > tbody > tr:nth-child(15) > td:nth-child(1) > a

driver.find_element_by_partial_link_text('2-1').click()
sleep(4)
# driver.find_element_by_link_text("查看全部评论").click()
# driver.switch_to.window(home_handle)
driver.find_element_by_partial_link_text('3-1').click()
sleep(2)

# all_handles = driver.window_handles
# for handle in all_handles:
#     if handle != home_handle:
#         driver.switch_to.window(handle)
#         driver.find_element_by_link_text("查看全部评论").click()
#         sleep(4)

driver.quit()


