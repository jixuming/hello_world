#!/usr/bin/env python
# -*- coding:utf-8 -*-
# created by dwm on 2018/10/30

from LoginPage import *
from selenium import webdriver
from time import sleep

driver = webdriver.Chrome()

username = "51zxw"
password = "123456"

test_user_login(driver, username, password)
sleep(3)
driver.quit()
