#!/usr/bin/env python
# -*- coding:utf-8 -*-
# created by dwm on 2018/10/30

from BasePage import *
from selenium.webdriver.common.by import By

class LoginPage(Page):
    url = '/'
    username_loc = (By.NAME, "username")
    password_loc = (By.NAME, "password")
    submit_loc = (By.NAME, "Submit")

    def typle_name(self, username):
        self.find_element(*self.username_loc).clear()
        self.find_element(*self.username_loc).send_keys(username)

    def typle_password(self, password):
        self.find_element(*self.password_loc).clear()
        self.find_element(*self.password_loc).send_keys(password)

    def typle_submit(self):
        self.find_element(*self.submit_loc).click()

def test_user_login(driver, username, password):
    login_page = LoginPage(driver)
    login_page.open()
    login_page.typle_name(username)
    login_page.typle_password(password)
    login_page.typle_submit()








if __name__ == '__main__':
    pass