#!/usr/bin/env python
# -*- coding:utf-8 -*-
# created by dwm on 2018/10/3

from time import ctime, sleep
import threading
import multiprocessing

#单线程
def talk():
    print("start talk:%r" % ctime())
    sleep(2)


def write():
    print("start write:%r" % ctime())
    sleep(3)

#多线程
def talking(content, loop):
    for i in range(loop):
        print('start talking %s, %s' % (content, ctime()))
        sleep(2)

def speak(content, loop):
    for i in range(loop):
        print('start speak %s, %s' % (content, ctime()))
        sleep(3)

#多线程
def talking1(content, loop):
    for i in range(loop):
        print('start talking %s, %s' % (content, ctime()))
        sleep(2)

def speak1(content, loop):
    for i in range(loop):
        print('start speak %s, %s' % (content, ctime()))
        sleep(3)

threaths = []
t1 = threading.Thread(target=talking, args=('51zxw', 2))
threaths.append(t1)

t2 = threading.Thread(target=speak, args=('51zxw', 2))
threaths.append(t2)

process = []
t3 = multiprocessing.Process(target=talking1, args=('51zxw', 2))
process.append(t3)

t4 = multiprocessing.Process(target=speak1, args=('51zxw', 2))
process.append(t4)

if __name__ == '__main__':
    talk()
    write()
    print('over %r' % ctime())

    for t in threaths:
        t.start()
    for t in threaths:
        t.join()
    print('thraeds is over %s' % ctime())

    for t in process:
        t.start()
    for t in process:
        t.join()
    print('process is over %s' % ctime())

