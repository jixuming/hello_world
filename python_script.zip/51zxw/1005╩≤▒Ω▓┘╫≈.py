#!/usr/bin/env python
# -*- coding:utf-8 -*-
# created by dwm on 2018/10/5


from selenium import webdriver
from time import sleep
from selenium.webdriver.common.action_chains import ActionChains


driver = webdriver.Chrome()
driver.get('https://www.baidu.com')
driver.maximize_window()

driver.find_element_by_css_selector('#kw').send_keys("Python")
element = driver.find_element_by_css_selector('#kw')
sleep(3)

ActionChains(driver).double_click(element).perform()
sleep(3)

ActionChains(driver).context_click(element).perform()
sleep(3)

# setting = driver.find_element_by_css_selector("#u > a.pf")
setting = driver.find_element_by_css_selector("#u > a:nth-child(3)")


# setting = driver.find_element_by_css_selector('#u>a[class="pf"]')
# setting = driver.find_element_by_css_selector(".pf")
ActionChains(driver).move_to_element(setting).perform()
sleep(3)

driver.quit()
if __name__ == '__main__':
    pass