#!/usr/bin/env python
# -*- coding:utf-8 -*-
# created by dwm on 2018/10/6


from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from time import sleep, ctime
from selenium.common.exceptions import NoSuchElementException

driver = webdriver.Chrome()
driver.maximize_window()
driver.get('http://www.baidu.com')
sleep(2)

# #显示等待
# driver.find_element_by_css_selector('#kw').send_keys('邓文明')
# element = WebDriverWait(driver, 10, 0.5).until(EC.presence_of_element_located((By.ID, 'su')))
# element.click()
# sleep(4)

#隐式等待
driver.implicitly_wait(5)
try:
    print(ctime())
    driver.find_element_by_css_selector('#kw').send_keys('python')
    driver.find_element_by_css_selector('#su111').click()
except NoSuchElementException as msg:
    print(msg)
finally:
    print(ctime())
sleep(2)



driver.quit()

if __name__ == '__main__':
    pass