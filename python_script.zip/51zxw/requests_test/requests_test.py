#!/usr/bin/env python
# -*- coding:utf-8 -*-
# created by dwm on 2018/11/13

import requests

base_url = "http://httpbin.org"
r = requests.get(base_url + "/get")
print(r.status_code)




if __name__ == '__main__':
    pass