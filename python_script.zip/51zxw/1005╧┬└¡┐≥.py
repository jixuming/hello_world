#!/usr/bin/env python
# -*- coding:utf-8 -*-
# created by dwm on 2018/10/5


from selenium import webdriver
from time import sleep
from selenium.webdriver.support.ui import Select

driver = webdriver.Chrome()
driver.get('https://www.hao123.com/')
sleep(3)
driver.find_element_by_css_selector('.arrow').click()
driver.find_element_by_css_selector('[data-tab="image"]').click()
# select_area = Select(driver.find_element_by_xpath("//div[@class='right tabs tabs-hook']"))
# select_area.select_by_index(2)
sleep(3)

driver.quit()

if __name__ == '__main__':
    pass
