#!/usr/bin/env python
# -*- coding:utf-8 -*-
# created by dwm on 2018/10/5

from selenium import webdriver
from time import sleep
from selenium.webdriver.common.keys import Keys

driver = webdriver.Chrome()
driver.get('https://www.baidu.com')
driver.maximize_window()
sleep(2)

driver.find_element_by_css_selector('#kw').send_keys('pythonn')
driver.find_element_by_css_selector('#kw').send_keys(Keys.BACK_SPACE)
sleep(2)
driver.find_element_by_css_selector('#kw').send_keys(Keys.SPACE)
sleep(2)
driver.find_element_by_css_selector('#kw').send_keys('教程')
sleep(2)
driver.find_element_by_css_selector('#kw').send_keys(Keys.CONTROL, 'a')
driver.find_element_by_css_selector('#kw').send_keys(Keys.CONTROL, 'x')

driver.get('http://www.sogou.com')
sleep(2)
driver.find_element_by_css_selector('.sec-input').send_keys(Keys.CONTROL, 'v')
driver.find_element_by_css_selector('#stb').send_keys(Keys.ENTER)
sleep(3)

driver.quit()





if __name__ == '__main__':
    pass