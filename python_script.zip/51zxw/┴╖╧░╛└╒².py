#coding:utf8

from selenium import webdriver
import unittest

class LoginCase(unittest.TestCase):

    def setUp(self):
        self.driver = webdriver.Chrome()
        self.driver.implicitly_wait(10)
        self.url='https://www.tapd.cn/cloud_logins/login'

    def tearDown(self):
        self.driver.quit()

    def by_id(self,id):
        return self.driver.find_element_by_id(id)


    def by_css(self,css):
        return self.driver.find_element_by_css_selector(css)

    def username_field(self):
        return self.by_id('username')

    def password_field(self):
        return self.by_id('password_input')

    def login_button(self):
        return self.by_id('tcloud_login_button')

    def daiban(self):
        return self.by_css('.current.ul-inline a')

    def login_action(self,username,password):
        self.username_field().clear()
        self.username_field().send_keys(username)
        self.password_field().clear()
        self.password_field().send_keys(password)
        self.login_button().click()

    def test_login_successs(self):
        self.driver.get(self.url)
        username = '13265862660'
        password = '680795242779dwm*'
        self.login_action(username,password)
        text = self.daiban().text
        self.assertEqual('我的',text)

if __name__ == "__main__":
    unittest.main()







