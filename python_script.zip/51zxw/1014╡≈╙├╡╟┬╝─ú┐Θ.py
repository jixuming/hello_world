#!/usr/bin/env python
# -*- coding:utf-8 -*-
# created by dwm on 2018/10/14

from Login import *
from selenium import webdriver

driver = webdriver.Chrome()
driver.get('http://localhost')
driver.implicitly_wait(10)
Login().user_login(driver)
Login().login_out(driver)
driver.quit()





