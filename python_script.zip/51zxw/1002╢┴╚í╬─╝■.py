#!/usr/bin/env python
# -*- coding:utf-8 -*-
# created by dwm on 2018/10/2

import csv
from xml.dom import minidom

##读取txt文件
# f = open ("./selenium自动化测试/sc3/3-1~3-10脚本和板书/3-11~3-33 Script(1015优化)/3-11~3-33/stu_info.txt")
# lines = f.readlines()
# print(lines)
#
# for line in lines:
#     print(line.split(",")[0])
##读取csv文件
# csv_file = csv.reader(open('./selenium自动化测试/sc3/3-1~3-10脚本和板书/3-11~3-33 Script(1015优化)/3-11~3-33/stu_info.csv',
#                            'r'))
# for stu in csv_file:
#     print(stu[2])

# #写入csv文件
# stu = ['marry', '28', 'changsha']
# stu1 = ['rom', '27', 'chengdou']
# out = open('./selenium自动化测试/sc3/3-1~3-10脚本和板书/3-11~3-33 Script(1015优化)/3-11~3-33/stu_info.csv', 'w',
#            newline='')
# csv_write11 = csv.writer(out, dialect='excel')
# csv_write11.writerow(stu)
# csv_write11.writerow(stu1)
# print('写入完成')

#读取xml文件属性
dom = minidom.parse('Class_info.xml')
root = dom.documentElement
print(root.nodeName)
print(root.nodeValue)
print(root.nodeType)

names = root.getElementsByTagName('name')
age = root.getElementsByTagName('age')
city = root.getElementsByTagName('city')
logins = root.getElementsByTagName('login')
students = root.getElementsByTagName('student')

print(students[0].nodeName)
print(students[0].tagName)
print(students[0].nodeValue)
print(students[0].nodeType)


for i in range(4):
    print(names[i].firstChild.data)
    print(age[i].firstChild.data)
    print(city[i].firstChild.data)

for i in range(2):
    username = logins[i].getAttribute('username')
    passwd = logins[i].getAttribute('passwd')
    print(username)
    print(passwd)







