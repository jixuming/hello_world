#!/usr/bin/env python
# -*- coding:utf-8 -*-
# created by dwm on 2018/10/14
from selenium import webdriver
from time import sleep




class Login:
    def user_login(self, driver):
        driver.find_element_by_css_selector('[name="username"]').clear()
        driver.find_element_by_css_selector('[name="username"]').send_keys('51zxw')
        driver.find_element_by_css_selector('[name="password"]').clear()
        driver.find_element_by_css_selector('[name="password"]').send_keys('123456')
        driver.find_element_by_css_selector('[name="Submit"]').click()

    def login_out(self, driver):
        driver.find_element_by_link_text("退出").click()
        sleep(2)
        driver.switch_to_alert().accept()


if __name__ == '__main__':
    driver = webdriver.Chrome()
    driver.get('http://localhost')
    driver.implicitly_wait(10)
    Login().user_login(driver)
    Login().login_out(driver)
    driver.quit()






