#!/usr/bin/env python
# -*- coding:utf-8 -*-
# created by dwm on 2018/10/7

from selenium import webdriver
from time import sleep

driver = webdriver.Chrome()
driver.maximize_window()
driver.get('http://www.51zxw.net/')
sleep(5)
#滚动条拖到底部
# js = "var action = document.documentElement.scrollTop = 10000"
js = "window.scrollTo(1,100000)"
driver.execute_script(js)
sleep(4)

js = "var action = document.documentElement.scrollTop = 0"
driver.execute_script(js)
sleep(2)

js = "var action = document.documentElement.scrollTop = 500"
driver.execute_script(js)
sleep(2)
driver.quit()



if __name__ == '__main__':
    pass