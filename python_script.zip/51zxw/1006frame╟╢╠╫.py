#!/usr/bin/env python
# -*- coding:utf-8 -*-
# created by dwm on 2018/10/6


from selenium import webdriver
from time import sleep

driver = webdriver.Chrome()
file_path = r'D:\python script\Frame.html'
driver.get(file_path)
# driver.switch_to_frame('search')
driver.switch_to.frame('search')
driver.find_element_by_css_selector('#query').send_keys('python')
driver.find_element_by_css_selector('#stb').click()
sleep(3)
driver.quit()


if __name__ == '__main__':
    pass