# 创建一篇文章

创建文章的测试用例可以帮我们实战下面的一些内容

* 表单元素的操作
* 富文本编辑器的操作
* 表单提交之后的断言

### 使用3A原则设计测试用例

希望大家没有忘记什么是3A原则。

* Arrange: 登录的用户名和密码admin/admin；文章的标题:test create post; 文章的正文: test create post
* Action: 成功登录；打开创建文章页面，输入标题和正文，点击创建按钮
* Assert: 到所有文章页面，此时最新的那篇文章标题应该是test create post

上面的用例执行一遍是没有问题的，但第二遍执行的时候就有问题了。因为每次执行时候文章的标题都一样，所以任何一次执行失败后我们可能都会发现最新的那篇文章的标题是test create post。

我们可以通过每次生成**不重复**的标题的方式来解决这个问题。

* Arrange: 登录的用户名和密码admin/admin；文章的标题:test12423421424; 文章的正文: test12423421424
* Action: 成功登录；打开创建文章页面，输入标题和正文，点击创建按钮
* Assert: 到所有文章页面，此时最新的那篇文章标题应该是test12423421424

上文的test12423421424就代表不重复的的标题。

### 关于用例名称

用例名称要表明这个用例是做什么的，这样用例失败的时候通过用例名称就能很快的定位出系统的问题。

好的名称

* test_create_post_success
* test_login_failed

不好的名称

* test1
* test2

### 代码

```python
class LoginCase(unittest.TestCase):

    def setUp(self): #每个用例执行之前执行
        print 'before test'
        self.dr = webdriver.Firefox()
        self.dr.get('http://localhost/wordpress/wp-login.php')

    def test_login(self):
        user_name = password = 'admin'
        self.login(user_name, password)

        self.assertTrue('wp-admin' in self.dr.current_url)
        greeting_link = self.by_css('#wp-admin-bar-my-account .ab-item')
        self.assertTrue(user_name in greeting_link.text)

    def test_create_post(self):
        self.login_as_admin()

        self.dr.get('http://localhost/wordpress/wp-admin/post-new.php')
        title = 'This is my post for py se 10 %s' %(time.time())
        self.by_id('title').send_keys(title)
        self.set_content('post body')
        self.by_id('publish').click()

        self.dr.get('http://localhost/wordpress/wp-admin/edit.php')
        new_post_title = self.by_css('.row-title').text
        self.assertTrue(new_post_title == title)

    def set_content(self, text):
        js = 'document.getElementById("content_ifr").contentWindow.document.body.innerHTML="%s"' %(text)
        print(js)
        self.dr.execute_script(js)

    def login(self, user_name, password):
        self.by_id('user_login').send_keys(user_name)
        self.by_id('user_pass').send_keys(password)
        self.by_id('wp-submit').click()

    def login_as_admin(self):
        user_name = password = 'admin'
        self.login(user_name, password)

    def by_id(self, the_id):
        return self.dr.find_element_by_id(the_id)

    def by_css(self, css):
        return self.dr.find_element_by_css_selector(css)

    def by_name(self, name):
        return self.dr.find_element_by_name(name)

    def tearDown(self): #每个用例执行之后
        print 'after every test'
        self.dr.quit()

if __name__ == '__main__':
    unittest.main()
```

### 代码分析

* 注意```login(self, user_name, password)```方法，由于登录是一个很常用的功能，因此我们把这个抽象成公共的方法；
* ```js = 'document.getElementById("content_ifr").contentWindow.document.body.innerHTML="%s"' %(text)```，使用js去写富文本的值，这是个套路，先记住就好。另外大家在selenium里执行js之前**一定要先在页面上用开发者工具把js调试好**，确保js一定是正确的再写进代码，这样能节省非常多的时间；
