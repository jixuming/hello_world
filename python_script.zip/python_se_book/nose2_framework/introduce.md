# 测试框架

### 测试框架的组成

* 方便的定义和使用测试数据和测试配置
* ui与用例逻辑分离
* 用例执行与过滤
* 测试报告的展示
* 元素动态等待与截图

### nose2

[nose2](http://nose2.readthedocs.io/en/latest/index.html)可以增强unittest的功能，可以方便我们定义用例，执行用例，生成测试报告以及自定义更多扩展。

```
pip install nose2
```

nose2的使用方法

```
usage: nose2 [-s START_DIR] [-t TOP_LEVEL_DIRECTORY] [--config [CONFIG]]
             [--no-user-config] [--no-plugins] [--plugin PLUGINS]
             [--exclude-plugin EXCLUDE_PLUGINS] [--verbose] [--quiet]
             [--log-level LOG_LEVEL] [--coverage PATH]
             [--coverage-report TYPE] [--coverage-config FILE] [-C] [-D]
             [--log-capture] [-B] [-F] [-h]
             [testNames [testNames ...]]

positional arguments:
  testNames

optional arguments:
  -s START_DIR, --start-dir START_DIR
                        Directory to start discovery ('.' default)
  -t TOP_LEVEL_DIRECTORY, --top-level-directory TOP_LEVEL_DIRECTORY, --project-directory TOP_LEVEL_DIRECTORY
                        Top level directory of project (defaults to start dir)
  --config [CONFIG], -c [CONFIG]
                        Config files to load, if they exist. ('unittest.cfg'
                        and 'nose2.cfg' in start directory default)
  --no-user-config      Do not load user config files
  --no-plugins          Do not load any plugins. Warning: nose2 does not do
                        anything if no plugins are loaded
  --plugin PLUGINS      Load this plugin module.
  --exclude-plugin EXCLUDE_PLUGINS
                        Do not load this plugin module
  --verbose, -v         print test case names and statuses
  --quiet
  --log-level LOG_LEVEL
                        Set logging level for message logged to console.
  -h, --help            Show this help message and exit
  ```

### 元素动态等待与截图

```python
def screenshot_on_exception(self, locator):
	try:
		WebDriverWait(self.driver, DEFAULT_SECONDS).until(EC.visibility_of_element_located(locator))
	except TimeoutException as e:
		# print(self.gen_screenshot_path(locator))
		self.driver.get_screenshot_as_file(self.gen_screenshot_path(locator))
		msg = "Time out when locate element using %s: %s" %(locator[0], locator[-1])
		raise TimeoutException(msg)
```

### 用例的定义和运行

默认情况下nose2会寻找所有```test```开头的文件当作测试用例，当然我们也可以手动指定每次运行哪个文件

```
nose2 test_login
```

我们也可以自定义用例规则

unittest.cfg
```
[unittest]
start-dir = tests
code-directories = source
                   more_source
test-file-pattern = *_test.py
test-method-prefix = t
```

### ui与用例逻辑分离

page object模式

### 测试报告的展示

nose2[自带了](http://nose2.readthedocs.io/en/latest/plugins/junitxml.html)junit格式测试报告的生成功能。

配置方式

unittest.cfg
```
[unittest]
plugins = nose2.plugins.junitxml

[junit-xml]
always-on = True
keep_restricted = False
path = resport.xml
test_fullname = False
```

运行用例后，当前文件夹会出现report.xml，我们可以解析这个文件，将关键数据入库，也可以使用jenkins去展示该文件。

### 测试数据与配置

可以新建config文件夹，定义data.py文件


```python
TEST_DATA = {
    'username': 'admin',
    'password': 'admin'
}
```

可以这样使用测试数据

```python
from config.data import CONFIG

def test_login_success(self):
    username = TEST_DATA['username']
    password = TEST_DATA['password']

    login_page = LoginPage(self.dr, 'wp-login.php')
    dashboard_page = login_page.login(username, password)
    ......
    ......
    ......

```

我们还可以实现不同环境加载不同配置选项的功能

config/data.py

```python

import os
if os.environ['SETESTENV']:
    ENV = os.environ['SETESTENV']
else:
    ENV = 'test'

CONFIG = {
    'domain': 'http://localhost/wordpress/',
    'test': {
        'domain': 'http://localhost/wordpress/',
    },
    'production': {
        'domain': 'http://www.itest.info/wordpress/'
    }
}

```

调用方式

```python
class BasePage(object):
	url = None
	driver = None
	domain = None

	def __init__(self, driver, path=None):
		self.driver = driver
		self.domain = CONFIG[ENV]['domain']

		if path:
			self.url = self.domain + path
		else:
			self.url = None

		if self.url != None:
			self.navigate()
```

在命令行中设置环境变量并运行

```
set SETESTENV=production
nose2
```
