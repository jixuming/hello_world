# 使用po重构登录成功的测试用例

登录成功的过程中，我们会涉及到2个页面，分别是登录的页面，我们叫做LoginPage和登录成功后跳转到的仪表盘页面DashboardPage。

我们在写po的时候，先捋清楚页面，然后把每个页面中用到的元素定位下来，再取个好辨识的名字，以便用例在调用时具有更好的表意性。通过操作这些元素，我们又可以封装出当前页面上的一些常用方法，比如下面代码中的```login```方法。

定义好po类之后，我们需要在用例中实例化用到的po类，对这个对象进行操作。


### 代码

```python
# base_page.py
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
# https://github.com/easonhan007/webdriver_guide/blob/master/34/expected_conditions.py.md

DEFAULT_SECONDS = 5
class BasePage(object):
	url = None
	driver = None
	domain = None

	def __init__(self, driver, page_url=None):
		self.driver = driver
		self.domain = 'http://localhost/wordpress/'
		self.url = page_url
		if self.url != None:
			self.navigate()

	def title(self):
		return self.driver.get_title()

	def url(self):
		return self.url

	def fill_form_by_css(self, form_css, value):
		elem = self.driver.find_element_by_css_selector(form_css)
		elem.send_keys(value)

	def fill_form_by_id(self, form_element_id, value):
		return self.fill_form_by_css('#%s' % form_element_id, value)

	def navigate(self):
		self.driver.get(self.url)

	def by_id(self, the_id):
		locator = (By.ID, the_id)
		WebDriverWait(self.driver, DEFAULT_SECONDS).until(EC.visibility_of_element_located(locator))
		return self.driver.find_element_by_id(the_id)

	def by_name(self, the_name):
		return self.driver.find_element_by_name(the_name)

	def by_css(self, css):
		return self.driver.find_element_by_css_selector(css)

	def js(self, js_text):
		return self.driver.execute_script(js_text)
```

```python
# login_page.py
from base_page import BasePage
from dashboard_page import DashboardPage

class LoginPage(BasePage):
    @property
    def username_text_field(self):
        return self.by_id('user_login')

    @property
    def password_text_field(self):
        return self.by_id('user_pass')

    @property
    def login_btn(self):
        return self.by_id('wp-submit')

    def login(self, username, password):
        self.username_text_field.send_keys(username)
        self.password_text_field.send_keys(password)
        self.login_btn.click()

        return DashboardPage(self.driver)
```

```python
# dashboard_page.py
from base_page import BasePage

class DashboardPage(BasePage):
    @property
    def greeting_link(self):
        return self.by_css('#wp-admin-bar-my-account .ab-item')
```

```python
# login_case.py

#coding: utf-8
import unittest
from selenium import webdriver
from selenium.webdriver.common.action_chains import ActionChains
from urlparse import urlparse, parse_qs
import time
from page.login_page import LoginPage
from page.dashboard_page import DashboardPage

class LoginCase(unittest.TestCase):

    def setUp(self): #每个用例执行之前执行
        print 'before test'
        self.domain = 'http://localhost/wordpress/'
        self.dr = webdriver.Firefox()

    def test_login_success(self):
        username = password = 'admin'
        login_page = LoginPage(self.dr, self.domain + 'wp-login.php')
        dashboard_page = login_page.login(username, password)

        self.assertTrue('wp-admin' in self.dr.current_url)
        self.assertTrue(username in dashboard_page.greeting_link.text)

    def tearDown(self): #每个用例执行之后
        print 'after every test'
        self.dr.quit()
```
