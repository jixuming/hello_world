# 添加HTML测试报告

### 使用BSRunnder

[BSRunnder](https://github.com/easonhan007/HTMLTestRunner)github地址

```python
import unittest
import BSTestRunner

class StringTestCase(unittest.TestCase):

    def setUp(self):
        self.test_string = "This is a string"

    def testReverse(self):
        self.assertEqual("gnirts a si sihT", self.test_string[::-1])

    def testSplit(self):
        expected = ["This", "is", "a", "string"]
        self.assertEqual(expected, self.test_string.split(" "))
        self.assertEqual(expected, self.test_string.split())

    def testLower(self):
        self.assertEqual("this is a string", self.test_string.lower())

    def testUpper(self):
        self.assertEqual("THIS IS A STRING", self.test_string.upper())

    def testRstrip(self):
        string = "This is a string               "
        self.assertEqual(self.test_string, string.rstrip())

    def testLstrip(self):
        string = "            This is a string"
        self.assertEqual(self.test_string, string.lstrip())

    def testStrip(self):
        string = "            This is a string             "
        self.assertEqual(self.test_string, string.strip())


if __name__ == '__main__':
    BSTestRunner.main()

```

### 修改构建脚本

```
python string_test_case_with_bs.py > report.html
```

### 启动server

cd到report.html所在目录


```
python -m SimpleHTTPServer # python2
python -m http.server # python3
```

在浏览器中访问[http://localhost:8000/](http://localhost:8000/)既可。


### 修改jenkins默认配置

如果workspace中无法正常展示html，那么请参考[这里](https://stackoverflow.com/questions/34315723/blocked-script-execution-in-url-because-the-documents-frame-is-sandboxed-and)
