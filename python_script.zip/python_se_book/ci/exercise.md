# 实战：使用jenkins运行wordpress测试用例

### 目的

* 巩固jenkins job的配置
* 学习配置运行脚本

### 场景

创建1个jenkins任务，要求每隔半小时自动执行wordpress测试用例
