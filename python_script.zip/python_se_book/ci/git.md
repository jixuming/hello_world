# git支持及代码库监控

### 代码库地址

[python string test](https://coding.net/u/easonhan/p/python_string_test_case/git)公共库地址。

### 配置要点

![](imgs/source_code.png)

------------------------------

![](imgs/trigger.png)


### 效果

每隔15分钟去查一下代码库，如果有新代码提交，则自动进行构建。
