本章的主要内容是

* 持续集成的概念
* 搭建jenkins持续集成环境
* 创建jenkins job
* 使用jenkins运行smile task测试用例
