# 练习

本章的练习主要是帮助大家熟悉html，消除对前端页面的恐惧感和无力感。

### 微博内容抓取

* 抓取微博24小时[热门话题](http://d.weibo.com/100803?cfs=&Pl_Discover_Pt6Rank__5_filter=hothtlist_type%3D1#_0)的前15个，注意需要翻页，抓取的内容请保存至txt文件中，需要抓取阅读数;

* 抓取24小时[热门微博前十条](http://d.weibo.com/102803?from=unlogin_home&mod=pindao&type=hotweibo#_rnd1456632403002)保存成txt格式，需要抓取发帖人，正文的html，转发量，阅读量和赞的数量

### 抓取知乎热点

取知乎今日最热及本月最热的问题和首个回答，保存至html文件，该html文件的文件名应该是20160228_zhihu_today_hot.html，也就是日期+zhihu_today_hot.html

该练习的目的是实战```get_attribute()```的用法，一般来说我们可以把selenium当成是爬虫来用，如果你不嫌慢的话。在抓取页面信息时，```get_attribute()```方法可以帮助我们获取dom元素的id，class,title等属性值，这些属性值里往往包含了一些重要信息。


### 豆瓣内容抓取

* 抓取[豆瓣电影](http://movie.douban.com/nowplaying/shenzhen/)中的正在热映前12部电影，并按照评分排序，保存至txt文件

* 抓取豆瓣读书中的(http://book.douban.com/)最受关注图书，按照评分排序，并保存至txt文件中，需要抓取书籍的名称，作者，评分，体裁和一句话评论

### 抓取PM2.5信息

从[这里](http://www.pm25.com/shenzhen.html)抓取北京，深圳，上海，广州的pm2.5指数，并按照空气质量从优到差排序，保存在txt文档里
