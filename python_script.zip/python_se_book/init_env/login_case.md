# 登录wordpress的测试用例

### 测试用例的3A原则

大部分的测试用例，从单元测试用例到ui的自动化测试用例，基本上都包含下面3个部分，由于这些单词的首字母都是A，所以我们称为3A原则。

* Arrange: 准备测试数据

* Action: 执行测试步骤

* Assert: 断言

这里面断言是最难写的，需要一定的技巧跟经验。

一般情况下UI自动化测试用例的断言都是通过页面的表现（比如跳转，出现个什么提示）来判断用例的预期是否达到。

### 登录成功的情况

其实只需要正确的用户名和密码就可以登录成功了。

下面的例子里，我们使用用户名admin，密码admin登录wordpress系统。

```python
#coding: utf-8
import unittest
from selenium import webdriver
import time

class LoginCase(unittest.TestCase):

    def setUp(self): #每个用例执行之前执行
        print 'before test'
        self.dr = webdriver.Firefox()
        self.dr.get('http://localhost/wordpress/wp-login.php')

    def test_login_success(self):
        # Arrange
        username = password = 'admin'

        # Action
        self.by_id('user_login').send_keys(username)
        self.by_id('user_pass').send_keys(password)
        self.by_id('wp-submit').click()

        # Assert
        # 登录成功后，页面发生跳转
        self.assertTrue('wp-admin' in self.dr.current_url)

        # 右上角会显示登录的用户名
        greek_link = self.by_css('#wp-admin-bar-my-account .ab-item')
        # 用包含来判断是为了断言可以兼容多语言
        self.assertTrue(username in greek_link.text)

    def by_id(self, the_id):
        return self.dr.find_element_by_id(the_id)

    def by_css(self, css):
        return self.dr.find_element_by_css_selector(css)

    def by_name(self, name):
        return self.dr.find_element_by_name(name)

    def tearDown(self): #每个用例执行之后
        print 'after every test'
        self.dr.quit()

if __name__ == '__main__':
    unittest.main()

```

### 登录失败的情况

分下面一些场景

|场景|系统提示|
|-------------|
|用户名密码为空|无提示信息|
|正确的用户名, 密码不填| 错误：密码一栏为空。|
|正确的用户名, 密码乱填| 错误：为用户名admin指定的密码不正确。 忘记密码？|
|不正确的用户名, 密码乱填| 错误：无效用户名。 忘记密码？|
